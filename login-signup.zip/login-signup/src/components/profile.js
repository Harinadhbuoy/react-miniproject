// Impoerting required components 
import { useLocation, Link } from 'react-router-dom';
import { useState } from 'react';

//Creating user profile component
function User_profile() {
    const location = useLocation();
    const user = location.state.user;

    // UseState hook which initializes state as empty string first
    const [profileDetails, setProfileDetails] = useState({
        name: '',
        email: '',
        dob: '',
        adharnum: '',
        phno: '',
    });

    // FetchProfileDetails function which fetches logged in user data from database based on unique email which comes from login 
    const fetchProfileDetails = async () => {
        try {

            // Calling backend server with unique email 
            const response = await fetch(`http://localhost:3000/profile/${user.email}`);

            // Storing the response from server in a variable
            const data = await response.json();

            // Setting response into setProfileDetails hook
            setProfileDetails(data)

        }
        // Catching occurring eror
        catch (error) {
            console.error('Error fetching profile details:', error);
        }

    };

    // Invoking fetchProfileDetails function
    fetchProfileDetails();

    return (

        //Displaying user details 
        <div className='main-container'>
            <div className='profile-details'>
                <p><label>NAME:</label>{profileDetails.name}</p>
                <p><label>EMAIL:</label>{profileDetails.email}</p>
                <p><label>DOB:</label>{profileDetails.dob}</p>
                <p><label>PHONO.NO:</label>{profileDetails.phno}</p>
                <p><label>ADHAR.NO:</label>{profileDetails.adharnum}</p>
                <Link to="/login">goto login page</ Link>
            </div>
        </div>
    )
}

export default User_profile;
