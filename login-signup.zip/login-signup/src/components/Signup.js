// Importing required components
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

// Creating signup component
const Signup = () => {

  // Usesate hooks which initializs state value as an empty string
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [dob, setDob] = useState('');
  const [phno, setPhno] = useState('');
  const [adharnum, setAdharnum] = useState('');
  const [confirmpassword, setConfirmPassword] = useState('');
  const [passwordsMatch, setPasswordsMatch] = useState(true);
  const navigate = useNavigate();

  // Handlesignup function which performs some validations and calls backend server for storing data in database
  const handleSignUp = async (e) => {
    e.preventDefault();

    if (password !== confirmpassword) {
      console.error("password and confirm password din't matched");
      alert("password and confirm password din'nt match");
      setPasswordsMatch(false);
      return;
    }

    try {
      // Calling backend server here
      const response = await fetch('http://localhost:3000/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },

        // Passing user data to the server 
        body: JSON.stringify({ name, email, password, dob, phno, adharnum }),
      });

      const data = await response.json();
      console.log('Signed up successfully with ID:', data.id);
      alert("Registration successful");
      navigate('/login');
    }

    // Catching occurring
    catch (error) {
      console.error('Error signing up:', error);
    }
  };


  return (
    <div className="auth-form">
      <h2>Sign Up</h2>

      {/* Clicking on submit it calls the function handleSignUp */}
      <form onSubmit={handleSignUp}>
        <input type="text" class="input-feild" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required />
        <input type="email" class="input-feild" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input type="password" class="input-feild" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <input type="date" class="input-feild" placeholder="date of birth" value={dob} onChange={(e) => setDob(e.target.value)} required />
        <input type="text" class="input-feild" placeholder="phone number" value={phno} onChange={(e) => setPhno(e.target.value)} required />
        <input type="text" class="input-feild" placeholder="adhar number" value={adharnum} onChange={(e) => setAdharnum(e.target.value)} required />
        <input type="password" class="input-feild" placeholder=" confirm Password" value={confirmpassword} onChange={(e) => {
          setConfirmPassword(e.target.value);
          setPasswordsMatch(e.target.value === password);
        }} required />
        {!passwordsMatch && <p style={{ color: 'red' }}>passwords did'nt matched</p>}
        <button type="submit">Sign Up</button><br/>
        <Link to="/login">already have an acc login</ Link>
      </form>
    </div>
  );
};

export default Signup;