// Importing required components
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

// Creating login component
const Login = () => {

  // Usesate hooks which initializs state value as an empty string
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  // HandleLogin function which store user login credentials and calls the backend to check wheather they are registered users or not and based respponse
  // From server if the user exists then it navigates to user profile page and displays their data 
  const handleLogin = async (e) => {
    e.preventDefault();
    try {

      // Calling backend server here
      const response = await fetch('http://localhost:3000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },

        //passing login credentials to server for validation
        body: JSON.stringify({ email, password }),
      });

      // If response ok (user registered or exist) navigates to profile page
      if (response.ok) {
        const userData = await response.json();
        navigate('/profile', { state: { user: userData } });

      } else {
        const errorData = await response.json();
        console.error('Error logging in:', errorData.error);
      }

    }

    // Catching occuring error
    catch (error) {
      console.error('Error logging in:', error);
    }
  };



  return (
    <div className="auth-form">
      <h2>Login</h2>

      {/* Clicking on submit it calls the function handleLogin */}
      <form onSubmit={handleLogin}>
        <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required /><br/>
        <button className='logbtn' type="submit">Login</button>
        <p>Don't have account <Link to="/signup">Register here</ Link></p>
      </form>
    </div>
  );
};

export default Login;