// src/App.js

// Importing required components
import React from 'react';
import Signup from './components/Signup';
import Login from './components/Login';
import User_profile from './components/profile';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';

const App = () => {
  return (
    <div className="app">

      {/* Routing */}
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
         <Route path="/profile" element={<User_profile />} /> 
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;







