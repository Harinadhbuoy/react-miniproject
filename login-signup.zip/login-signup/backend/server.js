// Importing required modules from Nodejs
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { Pool } = require('pg');
const app = express();
const port = 3000;

// PostgreSQL database connection
const pool = new Pool({
    user: 'harinadh',
    host: 'localhost',
    database: 'nodelogin',
    password: 'harinadh5',
    port: 5432,
});

app.use(cors());
app.use(bodyParser.json());


// Signup route which inserts the user signup details into databse
app.post('/signup', async (req, res) => {
    const { name, email, password, dob, phno, adharnum } = req.body;
    try {
        const result = await pool.query(
            'INSERT INTO users (name, email, password, dob, phno, adharnum) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id',
            [name, email, password, dob, phno, adharnum]
        );
        // Sending response
        res.status(201).json({ id: result.rows[0].id });
    }

    // Catching occuring error
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'An error occurred while signing up' });
    }
});


// Profile route which checks the user mail in database if match found it retreives the entire record
app.get('/profile/:email', async (req, res) => {

    const { email } = req.params

    try {
        const result = await pool.query(
            'SELECT * FROM users WHERE email = $1',
            [email]
        );

        // Sending response
        res.status(200).json({ id: result.rows[0].id, name: result.rows[0].name, email: result.rows[0].email, dob: result.rows[0].dob, phno: result.rows[0].phno, adharnum: result.rows[0].adharnum });
    }

    // Catching occuring error
    catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({ error: 'An error occurred while updating the profile' });
    }
});



// Login route checks the user credentials for existence in database amd sends back response
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const result = await pool.query('SELECT * FROM users WHERE email = $1 AND password = $2', [
            email,
            password,
        ]);

        // If user exists the row length should be 1 based that it executes following if else condition
        if (result.rows.length === 1) {

            // Sending response
            res.status(200).json({ email: result.rows[0].email, name: result.rows[0].name });
        } else {
            res.status(401).json({ error: 'Invalid email or password' });
        }

    }

    // Catching occuring error
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'An error occurred while logging in' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});